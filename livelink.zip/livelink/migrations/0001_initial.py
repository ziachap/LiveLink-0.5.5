# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models
import stdimage.models
import django.utils.timezone
from django.conf import settings


class Migration(migrations.Migration):

    dependencies = [
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
    ]

    operations = [
        migrations.CreateModel(
            name='Artist',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('name', models.CharField(max_length=128)),
                ('bio', models.TextField(max_length=1000, null=True, blank=True)),
                ('genre', models.CharField(max_length=64, null=True, choices=[('Pop', 'Pop'), ('Reggae', 'Reggae'), ('Folk', 'Folk'), ('R&B/Soul', 'R&B/Soul'), ('Jazz', 'Jazz'), ('Indie', 'Indie'), ('Metal', 'Metal'), ('Rock', 'Rock'), ('Garage', 'Garage'), ('Drum & Bass', 'Drum & Bass'), ('House', 'House'), ('Hip Hop/Rap', 'Hip Hop/Rap'), ('Dubstep', 'Dubstep'), ('Grime', 'Grime'), ('Electronic', 'Electronic'), ('Dance', 'Dance'), ('Classical', 'Classical'), ('Gospel', 'Gospel')])),
                ('fb_link', models.URLField(max_length=500, null=True, blank=True)),
                ('sc_link', models.URLField(max_length=500, null=True, blank=True)),
                ('yt_link', models.URLField(max_length=500, null=True, blank=True)),
                ('embed_sc', models.URLField(max_length=500, null=True, blank=True)),
                ('logo', stdimage.models.StdImageField(null=True, upload_to='venue_logos/', blank=True)),
                ('cover', stdimage.models.StdImageField(null=True, upload_to='artist_logos/', blank=True)),
            ],
        ),
        migrations.CreateModel(
            name='Distributor',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('price', models.IntegerField(null=True)),
                ('link', models.URLField(max_length=500, null=True, blank=True)),
            ],
        ),
        migrations.CreateModel(
            name='DistributorBrand',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('name', models.CharField(max_length=128)),
                ('logo', stdimage.models.StdImageField(null=True, upload_to='distributor_logos/', blank=True)),
            ],
        ),
        migrations.CreateModel(
            name='Event',
            fields=[
                ('id', models.AutoField(serialize=False, primary_key=True)),
                ('name', models.CharField(max_length=128)),
                ('type', models.CharField(max_length=64, null=True, choices=[('Club Night', 'Club Night'), ('Live Music', 'Live Music'), ('Festival', 'Festival')])),
                ('description', models.TextField(max_length=2000, null=True, blank=True)),
                ('start_time', models.DateTimeField(default=django.utils.timezone.now)),
                ('end_time', models.DateTimeField(null=True, blank=True)),
                ('fb_link', models.URLField(max_length=500, null=True, blank=True)),
                ('cover', stdimage.models.StdImageField(default='/static/images/default_event.jpg', upload_to='event_logos/')),
                ('artists', models.ManyToManyField(related_name='artists', null=True, to='livelink.Artist', blank=True)),
                ('author', models.ForeignKey(related_name='author', to=settings.AUTH_USER_MODEL, null=True)),
            ],
        ),
        migrations.CreateModel(
            name='Profile',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('bio', models.TextField(max_length=1000, null=True, blank=True)),
                ('profile_pic', stdimage.models.StdImageField(null=True, upload_to='profile_pictures/', blank=True)),
                ('artist_following', models.ManyToManyField(related_name='artist_following', null=True, to='livelink.Artist', blank=True)),
                ('user', models.OneToOneField(to=settings.AUTH_USER_MODEL)),
            ],
        ),
        migrations.CreateModel(
            name='Venue',
            fields=[
                ('id', models.AutoField(serialize=False, primary_key=True)),
                ('name', models.CharField(max_length=256)),
                ('summary', models.TextField(max_length=1000, null=True, blank=True)),
                ('location', models.TextField(max_length=1000, null=True, blank=True)),
                ('longitude', models.DecimalField(default=-0.1275, max_digits=28, decimal_places=16)),
                ('latitude', models.DecimalField(default=51.5072, max_digits=28, decimal_places=16)),
                ('website', models.URLField(max_length=500, null=True, blank=True)),
                ('email', models.EmailField(max_length=254, null=True, blank=True)),
                ('logo', stdimage.models.StdImageField(null=True, upload_to='venue_logos/', blank=True)),
                ('cover', stdimage.models.StdImageField(default='/static/images/default_venue.jpg', null=True, upload_to='venue_covers/', blank=True)),
            ],
        ),
        migrations.AddField(
            model_name='profile',
            name='venue_following',
            field=models.ManyToManyField(related_name='venue_following', null=True, to='livelink.Venue', blank=True),
        ),
        migrations.AddField(
            model_name='event',
            name='venue',
            field=models.ForeignKey(to='livelink.Venue', null=True),
        ),
        migrations.AddField(
            model_name='distributor',
            name='distributor',
            field=models.ForeignKey(to='livelink.DistributorBrand', null=True),
        ),
        migrations.AddField(
            model_name='distributor',
            name='event',
            field=models.ForeignKey(to='livelink.Event', null=True),
        ),
    ]
